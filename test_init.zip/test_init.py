# -*- coding: utf-8 -*-

def test_sdl2():
    import sdl2

def test_sdl2mixer():
    import sdl2.sdlmixer

def test_sdl2ttf():
    import sdl2.sdlttf

def test_sdl2image():
    import sdl2.sdlimage

def test_sdl2gfx():
    import sdl2.sdlgfx

def test_sdl2init():
    import sdl2.ext
    sdl2.ext.init()
