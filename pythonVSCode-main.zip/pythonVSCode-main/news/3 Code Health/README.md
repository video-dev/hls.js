Changes that should not be user-facing.
