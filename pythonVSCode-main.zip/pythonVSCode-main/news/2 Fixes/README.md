Changes that fix broken behaviour.
