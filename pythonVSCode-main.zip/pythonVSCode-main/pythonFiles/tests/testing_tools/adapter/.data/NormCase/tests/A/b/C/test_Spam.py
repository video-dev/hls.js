
def test_okay():
    assert True
