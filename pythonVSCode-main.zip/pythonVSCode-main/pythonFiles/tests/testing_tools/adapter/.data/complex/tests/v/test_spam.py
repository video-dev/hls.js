from .spam import test_simple


def test_simpler(self):
    assert True
