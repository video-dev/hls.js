
def test_simple(self):
    assert True


class TestSimple(object):

    def test_simple(self):
        assert True
