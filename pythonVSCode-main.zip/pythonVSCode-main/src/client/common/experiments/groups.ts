// Experiment to check whether to show "Extension Survey prompt" or not.
export enum ShowExtensionSurveyPrompt {
    experiment = 'pythonSurveyNotification',
}
export enum InterpreterStatusBarPosition {
    Pinned = 'pythonInterpreterInfoPinned',
    Unpinned = 'pythonInterpreterInfoUnpinned',
}
